package picodiploma.dicoding.moviecatalogue;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class detail_film extends AppCompatActivity {

    private ImageView imageView;
    private TextView txtJudulFilm, txtDetailFilm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_film);
        Film items = getIntent().getParcelableExtra("items");
        imageView = findViewById(R.id.img_detail_film);
        txtJudulFilm = findViewById(R.id.txt_judul_film);
        txtDetailFilm = findViewById(R.id.txt_detail_film);
      //  Drawable myDrawable = getResources().getDrawable(items.getFoto());
        //Log.d("imagess", myDrawable + "");
        //imageView.setImageDrawable(myDrawable);
       //TypedArray imageView = getResources().obtainTypedArray(items.getFoto());
        imageView.setImageResource(items.getFoto());
        txtJudulFilm.setText(items.getTitle());
        txtDetailFilm.setText(items.getDescription());


    }
}
